# CS541-DeepLearning
Course Homework and Project

## Homework1
- Implement the Matrix Calculation in Python
- Prove simple mathmatical rule of Matrix Operation

## Homework2
- Derivation of cost function
- Regularization implementation
- Prove Hidden Markov Model

## Homework3
- Prove Newton Methods 
- Derivation of softmax regression
- Softmax regression Implementation and tunning on MNIST

## Homework4
- Softmax regression Neuron Implementation
- The code implements the layers back-propagation recursively.
